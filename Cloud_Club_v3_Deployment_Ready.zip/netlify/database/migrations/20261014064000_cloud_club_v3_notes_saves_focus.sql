-- Private student notebook, saved community posts, and completed focus sessions.
-- Existing v2 tables and user content are not modified.
CREATE TABLE IF NOT EXISTS cc_personal_notes (
  id UUID PRIMARY KEY,
  owner_id TEXT NOT NULL REFERENCES cc_members(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cc_notes_owner_idx ON cc_personal_notes(owner_id, updated_at DESC);
CREATE TABLE IF NOT EXISTS cc_saved_posts (
  user_id TEXT NOT NULL REFERENCES cc_members(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES cc_posts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(user_id,post_id)
);
CREATE TABLE IF NOT EXISTS cc_focus_sessions (
  id UUID PRIMARY KEY,
  owner_id TEXT NOT NULL REFERENCES cc_members(id) ON DELETE CASCADE,
  minutes INTEGER NOT NULL CHECK(minutes IN (15,25,45)),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cc_focus_owner_idx ON cc_focus_sessions(owner_id,created_at DESC);
