CREATE TABLE IF NOT EXISTS cc_members (
 id TEXT PRIMARY KEY, display_name TEXT NOT NULL DEFAULT 'Student', bio TEXT NOT NULL DEFAULT '',
 role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('owner','admin','member')),
 suspended BOOLEAN NOT NULL DEFAULT FALSE,
 allow_dm BOOLEAN NOT NULL DEFAULT FALSE,
 theme TEXT NOT NULL DEFAULT 'lavender',
 joined_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_blocks (
 blocker TEXT NOT NULL REFERENCES cc_members(id), blocked TEXT NOT NULL REFERENCES cc_members(id),
 PRIMARY KEY (blocker, blocked)
);
CREATE TABLE IF NOT EXISTS cc_groups (
 id UUID PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
 owner_id TEXT NOT NULL REFERENCES cc_members(id), invite_code TEXT NOT NULL UNIQUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_group_members (
 group_id UUID NOT NULL REFERENCES cc_groups(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES cc_members(id),
 PRIMARY KEY(group_id,user_id)
);
CREATE TABLE IF NOT EXISTS cc_messages (
 id UUID PRIMARY KEY, scope TEXT NOT NULL CHECK(scope IN ('general','homework','resources','group','dm')),
 space_id TEXT NOT NULL DEFAULT '', author_id TEXT NOT NULL REFERENCES cc_members(id),
 body TEXT NOT NULL CHECK(length(body) BETWEEN 1 AND 1000), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cc_messages_room_idx ON cc_messages(scope, space_id, created_at DESC);
CREATE TABLE IF NOT EXISTS cc_assignments (
 id UUID PRIMARY KEY, author_id TEXT NOT NULL REFERENCES cc_members(id),
 title TEXT NOT NULL, subject TEXT NOT NULL DEFAULT 'General', details TEXT NOT NULL DEFAULT '',
 due DATE, done BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_resources (
 id UUID PRIMARY KEY, author_id TEXT NOT NULL REFERENCES cc_members(id),
 title TEXT NOT NULL, link TEXT NOT NULL, blob_key TEXT, content_type TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_announcements (
 id UUID PRIMARY KEY, author_id TEXT NOT NULL REFERENCES cc_members(id),
 title TEXT NOT NULL, body TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_posts (
 id UUID PRIMARY KEY, author_id TEXT NOT NULL REFERENCES cc_members(id),
 body TEXT NOT NULL, options JSONB NOT NULL DEFAULT '[]'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_votes (
 post_id UUID NOT NULL REFERENCES cc_posts(id) ON DELETE CASCADE,
 voter_id TEXT NOT NULL REFERENCES cc_members(id), choice INTEGER NOT NULL CHECK(choice BETWEEN 0 AND 3),
 PRIMARY KEY(post_id,voter_id)
);
CREATE TABLE IF NOT EXISTS cc_decks (
 id UUID PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES cc_members(id),
 title TEXT NOT NULL, cards JSONB NOT NULL DEFAULT '[]'::jsonb,
 reviewed JSONB NOT NULL DEFAULT '[]'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_events (
 id UUID PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES cc_members(id),
 title TEXT NOT NULL, starts_at TIMESTAMPTZ NOT NULL,
 notes TEXT NOT NULL DEFAULT '', reminder_sent BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_notifications (
 id UUID PRIMARY KEY, user_id TEXT NOT NULL REFERENCES cc_members(id),
 title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', seen BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cc_reports (
 id UUID PRIMARY KEY, reporter_id TEXT NOT NULL REFERENCES cc_members(id),
 subject_id TEXT NOT NULL, subject_type TEXT NOT NULL, reason TEXT NOT NULL,
 evidence TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cc_notifications_user_idx ON cc_notifications(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS cc_groups_owner_idx ON cc_groups(owner_id);
