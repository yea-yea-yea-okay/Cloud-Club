import { getUser } from '@netlify/identity';
import { getDatabase } from '@netlify/database';
import { getStore } from '@netlify/blobs';
import { randomBytes, randomUUID } from 'node:crypto';

const json = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
const bad = (message, status = 400) => json({ error: message }, status);
const text = (value, max = 500) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const ident = x => typeof x === 'string' && /^[0-9a-f-]{36}$/i.test(x);
const channel = s => ['general', 'homework', 'resources'].includes(s);
const profileFields = 'm.id,m.display_name AS name,m.bio,m.role,m.suspended,m.allow_dm AS "allowDm",m.theme';
const privatePair = (a, b) => [a, b].sort().join('~');
const allowed = (record) => record && !record.suspended;
const isStaff = (me) => ['owner', 'admin'].includes(me.role);
const dateOK = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s));

export default async function handler(request) {
  if (!['GET', 'POST'].includes(request.method)) return bad('Method not allowed', 405);
  try {
    const identityUser = await getUser();
    if (!identityUser?.id) return bad('Sign in before using Cloud Club.', 401);
    const db = getDatabase();
    const sql = (query, params = []) => db.pool.query(query, params).then(x => x.rows);
    const post = request.method === 'POST';
    let input = {};
    if (post) {
      if (Number(request.headers.get('content-length') || 0) > 2100000) return bad('Upload is too large.', 413);
      try { input = await request.json(); } catch { return bad('Invalid request JSON'); }
      if (!input || typeof input !== 'object' || Array.isArray(input)) return bad('Invalid request');
    }
    const url = new URL(request.url);
    if (post && request.headers.get('origin') && new URL(request.headers.get('origin')).host !== url.host) return bad('Invalid request origin',403);
    const action = post ? text(input.action, 50) : text(url.searchParams.get('action'), 50);
    const id = post ? text(input.id, 100) : text(url.searchParams.get('id'), 100);
    const params = input;
    const myId = String(identityUser.id);
    const ownerEmail = String(Netlify.env.get('CLOUD_CLUB_OWNER_EMAIL') || '').trim().toLowerCase();
    const myEmail = String(identityUser.email || '').toLowerCase();

    // A name from an OAuth provider may contain a student's real name.
    // Default to a pseudonym and let the member choose an optional nickname.
    await sql(`INSERT INTO cc_members(id,display_name,role) VALUES($1,$2,$3)
      ON CONFLICT(id) DO NOTHING`, [myId, 'Student ' + myId.slice(0, 5).toUpperCase(), 'member']);
    // The verified Netlify Identity email is the only owner authority.
    // Revoking/changing the configured email also removes a stale owner role.
    if (ownerEmail && myEmail === ownerEmail) {
      // Prevent multiple persisted owners after the configured address changes.
      await sql("UPDATE cc_members SET role='member' WHERE role='owner' AND id<>$1", [myId]);
      await sql("UPDATE cc_members SET role='owner' WHERE id=$1", [myId]);
    } else {
      // The current account cannot keep a privileged role after its allowlist
      // entry is removed. Other people's roles are not modified by this login.
      await sql("UPDATE cc_members SET role='member' WHERE id=$1 AND role='owner'", [myId]);
    }
    const person = (await sql(`SELECT ${profileFields} FROM cc_members m WHERE m.id=$1`, [myId]))[0];
    if (!allowed(person)) return bad('Account suspended. Contact the site owner.', 403);
    const uid = myId;
    const memberExists = async target => (await sql('SELECT id,display_name AS name,allow_dm AS "allowDm", suspended FROM cc_members WHERE id=$1', [target]))[0];
    const blocked = async target => (await sql('SELECT 1 FROM cc_blocks WHERE (blocker=$1 AND blocked=$2) OR (blocker=$2 AND blocked=$1) LIMIT 1', [uid, target])).length > 0;
    const classMembership = async groupId => (await sql('SELECT g.id,g.title,g.description,g.invite_code AS "inviteCode",g.owner_id AS "ownerId" FROM cc_groups g JOIN cc_group_members gm ON gm.group_id=g.id WHERE g.id=$1 AND gm.user_id=$2', [groupId, uid]))[0];
    const addAlert = async (recipient, title, body = '') => sql('INSERT INTO cc_notifications(id,user_id,title,body) VALUES($1,$2,$3,$4)', [randomUUID(), recipient, title, body]);

    if (action === 'bootstrap' && !post) {
      const [members, assignments, resources, announcements, channels, classes, posts, decks, events, alerts, reports, blocks, notes, savedPosts, focusSessions, moderationMembers] = await Promise.all([
        sql(`SELECT id,display_name AS name,bio,role FROM cc_members WHERE suspended=false ORDER BY joined_at DESC LIMIT 100`),
        sql(`SELECT a.*,m.display_name AS author FROM cc_assignments a JOIN cc_members m ON m.id=a.author_id ORDER BY a.created_at DESC LIMIT 100`),
        sql(`SELECT r.id,r.title,r.link,r.blob_key AS "blobKey",r.content_type AS "contentType",r.created_at,m.display_name AS author,r.author_id FROM cc_resources r JOIN cc_members m ON m.id=r.author_id ORDER BY r.created_at DESC LIMIT 80`),
        sql(`SELECT a.id,a.title,a.body,a.created_at,m.display_name AS author FROM cc_announcements a JOIN cc_members m ON m.id=a.author_id ORDER BY a.created_at DESC LIMIT 60`),
        sql(`SELECT c.id,c.scope,c.space_id AS "spaceId",c.body,c.created_at,c.author_id,m.display_name AS author FROM cc_messages c JOIN cc_members m ON m.id=c.author_id WHERE c.scope IN ('general','homework','resources') ORDER BY c.created_at DESC LIMIT 160`),
        sql(`SELECT g.id,g.title,g.description,g.owner_id AS "ownerId",CASE WHEN g.owner_id=$1 THEN g.invite_code ELSE NULL END AS "inviteCode" FROM cc_groups g JOIN cc_group_members gm ON gm.group_id=g.id WHERE gm.user_id=$1 ORDER BY g.created_at DESC LIMIT 60`,[uid]),
        sql(`SELECT p.id,p.body,p.options,p.author_id,p.created_at,m.display_name AS author FROM cc_posts p JOIN cc_members m ON m.id=p.author_id ORDER BY p.created_at DESC LIMIT 60`),
        sql(`SELECT id,title,cards,reviewed,created_at FROM cc_decks WHERE owner_id=$1 ORDER BY created_at DESC LIMIT 80`,[uid]),
        sql(`SELECT id,title,starts_at,notes,reminder_sent FROM cc_events WHERE owner_id=$1 ORDER BY starts_at ASC LIMIT 100`,[uid]),
        sql(`SELECT id,title,body,seen,created_at FROM cc_notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50`,[uid]),
        isStaff(person) ? sql(`SELECT id,subject_type,reason,evidence,status,created_at FROM cc_reports ORDER BY created_at DESC LIMIT 80`) : Promise.resolve([]),
        sql('SELECT blocked FROM cc_blocks WHERE blocker=$1',[uid]),
        sql('SELECT id,title,body,created_at,updated_at FROM cc_personal_notes WHERE owner_id=$1 ORDER BY updated_at DESC LIMIT 100',[uid]),
        sql('SELECT post_id FROM cc_saved_posts WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[uid]),
        sql('SELECT id,minutes,created_at FROM cc_focus_sessions WHERE owner_id=$1 ORDER BY created_at DESC LIMIT 70',[uid]),
        isStaff(person) ? sql('SELECT id,display_name AS name,role,suspended FROM cc_members ORDER BY joined_at DESC LIMIT 100') : Promise.resolve([])
      ]);
      const postIds = posts.map(p => p.id);
      const votes = postIds.length ? await sql(`SELECT post_id,choice,count(*)::integer AS total FROM cc_votes WHERE post_id=ANY($1::uuid[]) GROUP BY post_id,choice`,[postIds]) : [];
      const mine = postIds.length ? await sql('SELECT post_id,choice FROM cc_votes WHERE voter_id=$1 AND post_id=ANY($2::uuid[])',[uid,postIds]) : [];
      const enriched = posts.map(p => ({...p,options: Array.isArray(p.options)?p.options:[],counts:(Array.isArray(p.options)?p.options:[]).map((_,i)=>votes.find(v=>v.post_id===p.id&&v.choice===i)?.total||0),myVote:mine.find(v=>v.post_id===p.id)?.choice??-1}));
      return json({ me: person, members, assignments, resources, announcements, channels, classes, posts: enriched, decks, events, alerts, reports, blocks, notes, savedPosts, focusSessions, moderationMembers });
    }
    if (action === 'profile' && post) {
      const name = text(params.name,30), bio = text(params.bio,160), theme = text(params.theme,20);
      if (name.length < 2) return bad('Use a display name of at least 2 characters.');
      if (theme && !['lavender','ocean','rose','sage','midnight'].includes(theme)) return bad('Invalid theme');
      await sql('UPDATE cc_members SET display_name=$1,bio=$2,theme=COALESCE(NULLIF($3,\'\'),theme) WHERE id=$4',[name,bio,theme,uid]);
      return json({ ok:true });
    }
    if (action === 'dm-setting' && post) {
      if (typeof params.enabled !== 'boolean') return bad('Invalid privacy setting');
      await sql('UPDATE cc_members SET allow_dm=$1 WHERE id=$2',[params.enabled,uid]); return json({ok:true});
    }
    if (action === 'block' && post) {
      const target = text(params.target,70);
      if (!target || target === uid || !(await memberExists(target))) return bad('Choose another registered member.');
      if (params.block === true) await sql('INSERT INTO cc_blocks(blocker,blocked) VALUES($1,$2) ON CONFLICT DO NOTHING',[uid,target]);
      else await sql('DELETE FROM cc_blocks WHERE blocker=$1 AND blocked=$2',[uid,target]);
      return json({ok:true});
    }
    if (action === 'blocks' && !post) return json({items:await sql('SELECT blocked FROM cc_blocks WHERE blocker=$1',[uid])});
    if (action === 'message' && post) {
      const scope = text(params.scope,15), body = text(params.body,800);
      let space = text(params.spaceId,100);
      if (!body) return bad('Write a message first');
      if (scope === 'group') {
        if (!ident(space) || !(await classMembership(space))) return bad('You are not a member of this private class.',403);
      } else if (scope === 'dm') {
        const target = await memberExists(space);
        if (!target || target.suspended || target.id === uid || !person.allowDm || !target.allowDm || (await blocked(space))) return bad('Both members must opt in to messages, and neither can be blocked.',403);
        space = privatePair(uid, space);
      } else if (!channel(scope)) return bad('Invalid channel');
      else space = '';
      const recent=await sql("SELECT count(*)::integer AS total FROM cc_messages WHERE author_id=$1 AND created_at>now()-interval '30 seconds'",[uid]);
      if ((recent[0]?.total||0)>=8) return bad('Slow down a little. Try messaging again shortly.',429);
      await sql('INSERT INTO cc_messages(id,scope,space_id,author_id,body) VALUES($1,$2,$3,$4,$5)',[randomUUID(),scope,space,uid,body]);
      if (scope === 'dm') await addAlert(text(params.spaceId,100),'New private message','Someone sent you a message.');
      return json({ok:true});
    }
    if (action === 'conversation' && !post) {
      const scope = text(url.searchParams.get('scope'),15), spaceId = text(url.searchParams.get('spaceId'),100);
      let space = spaceId;
      if (scope === 'group' && (!ident(space) || !(await classMembership(space)))) return bad('Private class membership required',403);
      if (scope === 'dm') {
        const target = await memberExists(space);
        if (!target || target.suspended || target.id===uid || await blocked(space)) return bad('This conversation is unavailable.',403);
        space = privatePair(uid,space);
      }
      if (channel(scope)) space = '';
      else if (scope !== 'group' && scope !== 'dm') return bad('Invalid channel');
      const items = await sql(`SELECT c.id,c.body,c.created_at,c.author_id,m.display_name AS author FROM cc_messages c JOIN cc_members m ON m.id=c.author_id WHERE c.scope=$1 AND c.space_id=$2 ORDER BY c.created_at DESC LIMIT 100`,[scope,space]);
      return json({items});
    }
    if (action === 'delete-message' && post) {
      if (!ident(id)) return bad('Invalid message');
      const result = (await sql('SELECT * FROM cc_messages WHERE id=$1',[id]))[0];
      if (!result) return bad('Not found',404);
      const owns = result.author_id === uid;
      const publicChat = channel(result.scope);
      if (result.scope==='group' && (!await classMembership(result.space_id))) return bad('Class access denied',403);
      if (result.scope==='dm' && result.space_id !== privatePair(uid,text(params.target,80))) return bad('Not your conversation',403);
      if (!owns && !(publicChat && isStaff(person))) return bad('Only the author can delete this message.',403);
      await sql('DELETE FROM cc_messages WHERE id=$1',[id]); return json({ok:true});
    }
    if (action === 'class-create' && post) {
      const title = text(params.title,75), description = text(params.description,200);
      if (title.length < 3) return bad('Please name your class');
      const groupId = randomUUID(), code = randomBytes(6).toString('hex').toUpperCase();
      const client = await db.pool.connect();
      try { await client.query('BEGIN'); await client.query('INSERT INTO cc_groups(id,title,description,owner_id,invite_code) VALUES($1,$2,$3,$4,$5)',[groupId,title,description,uid,code]); await client.query('INSERT INTO cc_group_members(group_id,user_id) VALUES($1,$2)',[groupId,uid]); await client.query('COMMIT'); }
      catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
      return json({ok:true,code});
    }
    if (action === 'class-join' && post) {
      const code = text(params.code,20).toUpperCase();
      if (!/^[A-F0-9]{12}$/.test(code)) return bad('Enter a valid class code.');
      const found = (await sql('SELECT id FROM cc_groups WHERE invite_code=$1',[code]))[0];
      if (!found) return bad('Class not found',404);
      await sql('INSERT INTO cc_group_members(group_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[found.id,uid]);
      return json({ok:true});
    }
    if (action === 'class-leave' && post) {
      if (!ident(id)) return bad('Invalid class');
      const g=await classMembership(id);
      if (!g) return bad('Not a member',403);
      if (g.ownerId===uid) return bad('Class creators cannot leave their own classes yet.');
      await sql('DELETE FROM cc_group_members WHERE group_id=$1 AND user_id=$2',[id,uid]);return json({ok:true});
    }
    if (action === 'task-create' && post) {
      const title=text(params.title,120),subject=text(params.subject,45)||'General',details=text(params.details,400);
      const due=params.due?text(params.due,10):null;
      if (!title || (due&&!dateOK(due))) return bad('Title and due date are required if specified');
      await sql('INSERT INTO cc_assignments(id,author_id,title,subject,details,due) VALUES($1,$2,$3,$4,$5,$6)',[randomUUID(),uid,title,subject,details,due]);return json({ok:true});
    }
    if (action === 'task-done' && post) {
      if (!ident(id) || typeof params.done!=='boolean') return bad('Invalid task');
      const r=await sql('UPDATE cc_assignments SET done=$1 WHERE id=$2 AND author_id=$3 RETURNING id',[params.done,id,uid]);
      return r.length ? json({ok:true}) : bad('Only the author can edit the task',403);
    }
    if (action === 'resource-link' && post) {
      const title=text(params.title,120),link=text(params.link,1800);
      let parsed;try{parsed=new URL(link);}catch{return bad('Use a valid HTTPS link');}
      if (!title || parsed.protocol!=='https:') return bad('Use a title and valid HTTPS link');
      await sql('INSERT INTO cc_resources(id,author_id,title,link) VALUES($1,$2,$3,$4)',[randomUUID(),uid,title,link]);return json({ok:true});
    }
    if (action === 'resource-upload' && post) {
      const title=text(params.title,120), mime=text(params.mime,80), base64=typeof params.base64==='string'?params.base64:'';
      if (!title || !['application/pdf','image/png','image/jpeg','text/plain'].includes(mime) || base64.length>1750000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(base64)) return bad('Only PDFs, images and TXT files under 1.2 MB are supported');
      const bytes=Buffer.from(base64,'base64');
      if(bytes.byteLength>1200000) return bad('File is too large');
      const key=randomUUID();
      await getStore('cloud-club-files').set(key,new Blob([bytes],{type:mime}));
      await sql('INSERT INTO cc_resources(id,author_id,title,link,blob_key,content_type) VALUES($1,$2,$3,$4,$5,$6)',[randomUUID(),uid,title,'',key,mime]);return json({ok:true});
    }
    if (action === 'file' && !post) {
      if (!ident(id)) return bad('Invalid file');
      const file=(await sql('SELECT blob_key,content_type,title FROM cc_resources WHERE id=$1',[id]))[0];
      if (!file?.blob_key) return bad('File not found',404);
      const value=await getStore('cloud-club-files').get(file.blob_key,{type:'blob'});
      if(!value) return bad('File unavailable',404);
      return new Response(value,{headers:{'Content-Type':file.content_type,'Content-Disposition':'attachment; filename="resource"','Cache-Control':'private,no-store','X-Content-Type-Options':'nosniff'}});
    }
    if (action === 'announcement-create' && post) {
      if(!isStaff(person)) return bad('Admins only',403);
      const title=text(params.title,100),body=text(params.body,700);
      if(!title||!body) return bad('Complete both fields');
      await sql('INSERT INTO cc_announcements(id,author_id,title,body) VALUES($1,$2,$3,$4)',[randomUUID(),uid,title,body]);
      const members=await sql('SELECT id FROM cc_members WHERE suspended=false LIMIT 100');
      for(const m of members) await addAlert(m.id,'Club announcement',title);
      return json({ok:true});
    }
    if (action === 'post-create' && post) {
      const body=text(params.body,900),options=Array.isArray(params.options)?params.options.slice(0,4).map(x=>text(x,85)).filter(Boolean):[];
      if(!body||(options.length>0&&options.length<2)) return bad('Add a message or two poll options.');
      const recent=await sql("SELECT count(*)::integer AS total FROM cc_posts WHERE author_id=$1 AND created_at>now()-interval '10 minutes'",[uid]);
      if((recent[0]?.total||0)>=6)return bad('You have posted a lot recently. Come back in a few minutes.',429);
      await sql('INSERT INTO cc_posts(id,author_id,body,options) VALUES($1,$2,$3,$4)',[randomUUID(),uid,body,JSON.stringify(options)]);return json({ok:true});
    }
    if (action === 'post-vote' && post) {
      if(!ident(id)||!Number.isInteger(params.choice)) return bad('Invalid vote');
      const p=(await sql('SELECT options FROM cc_posts WHERE id=$1',[id]))[0];
      if(!p?.options || params.choice<0 || params.choice>=p.options.length) return bad('Invalid poll choice');
      await sql('INSERT INTO cc_votes(post_id,voter_id,choice) VALUES($1,$2,$3) ON CONFLICT(post_id,voter_id) DO UPDATE SET choice=EXCLUDED.choice',[id,uid,params.choice]);return json({ok:true});
    }
    if (action === 'deck-create' && post) {
      const title=text(params.title,85),cards=Array.isArray(params.cards)?params.cards.slice(0,70).map(x=>({front:text(x.front,200),back:text(x.back,240)})).filter(x=>x.front&&x.back):[];
      if(!title||cards.length<2) return bad('Name your deck and include at least two cards');
      await sql('INSERT INTO cc_decks(id,owner_id,title,cards) VALUES($1,$2,$3,$4)',[randomUUID(),uid,title,JSON.stringify(cards)]);return json({ok:true});
    }
    if (action === 'deck-review' && post) {
      if(!ident(id)||!Number.isInteger(params.index)||typeof params.known!=='boolean') return bad('Invalid card');
      const deck=(await sql('SELECT cards,reviewed FROM cc_decks WHERE id=$1 AND owner_id=$2',[id,uid]))[0];
      if(!deck||params.index<0||params.index>=deck.cards.length) return bad('Deck not found',404);
      const reviewed=[...(deck.reviewed||[]).filter(x=>x!==params.index)];
      if(params.known)reviewed.push(params.index);
      await sql('UPDATE cc_decks SET reviewed=$1 WHERE id=$2 AND owner_id=$3',[JSON.stringify(reviewed),id,uid]);return json({ok:true});
    }
    if (action === 'event-create' && post) {
      const title=text(params.title,120),time=text(params.time,50),notes=text(params.notes,250);
      const begins=new Date(time);
      if(!title||!Number.isFinite(begins.getTime())) return bad('Give a title and valid date/time');
      await sql('INSERT INTO cc_events(id,owner_id,title,starts_at,notes) VALUES($1,$2,$3,$4,$5)',[randomUUID(),uid,title,begins.toISOString(),notes]);return json({ok:true});
    }
    if (action === 'report' && post) {
      const subjectType=text(params.type,20),itemId=text(params.itemId,100),reason=text(params.reason,300);
      if(reason.length<4||!ident(itemId)||!['post','message'].includes(subjectType))return bad('Select a post or message and provide a reason');
      let item;
      if(subjectType==='post') item=(await sql('SELECT body,author_id FROM cc_posts WHERE id=$1',[itemId]))[0];
      else {
        item=(await sql('SELECT * FROM cc_messages WHERE id=$1',[itemId]))[0];
        if(item?.scope==='dm' && (item.space_id!==privatePair(uid,text(params.partnerId,75))||item.author_id===uid))return bad('You can only report a received private message',403);
        if(item?.scope==='group' && !await classMembership(item.space_id))return bad('You are not in this private class',403);
      }
      if(!item)return bad('Reported content not found',404);
      await sql('INSERT INTO cc_reports(id,reporter_id,subject_id,subject_type,reason,evidence) VALUES($1,$2,$3,$4,$5,$6)',[randomUUID(),uid,itemId,subjectType,reason,text(item.body,800)]);return json({ok:true});
    }
    if (action === 'report-resolve' && post) {
      if(!isStaff(person))return bad('Admins only',403);
      await sql('UPDATE cc_reports SET status=$1 WHERE id=$2',[params.resolved?'resolved':'open',id]);return json({ok:true});
    }
    if (action === 'member-moderate' && post) {
      if(person.role!=='owner') return bad('Owner only',403);
      const target=text(params.target,75),operation=text(params.operation,12);
      if(target===uid || !['suspend','restore','promote','demote'].includes(operation))return bad('Invalid change');
      const chosen=(await sql('SELECT role FROM cc_members WHERE id=$1',[target]))[0];
      if(!chosen||chosen.role==='owner') return bad('Cannot change owner',403);
      if(operation==='suspend'||operation==='restore')await sql('UPDATE cc_members SET suspended=$1 WHERE id=$2',[operation==='suspend',target]);
      else await sql('UPDATE cc_members SET role=$1 WHERE id=$2',[operation==='promote'?'admin':'member',target]);
      return json({ok:true});
    }
    if (action === 'note-create' && post) {
      const title=text(params.title,110), content=text(params.body,5000);
      if (!title || !content) return bad('Add a note title and some content.');
      await sql('INSERT INTO cc_personal_notes(id,owner_id,title,body) VALUES($1,$2,$3,$4)',[randomUUID(),uid,title,content]);
      return json({ok:true});
    }
    if (action === 'note-update' && post) {
      const title=text(params.title,110), content=text(params.body,5000);
      if(!ident(id)||!title||!content)return bad('Complete your note before saving.');
      const items=await sql('UPDATE cc_personal_notes SET title=$1,body=$2,updated_at=now() WHERE id=$3 AND owner_id=$4 RETURNING id',[title,content,id,uid]);
      return items.length?json({ok:true}):bad('Note not found.',404);
    }
    if (action === 'note-delete' && post) {
      if(!ident(id))return bad('Invalid note.');
      const items=await sql('DELETE FROM cc_personal_notes WHERE id=$1 AND owner_id=$2 RETURNING id',[id,uid]);
      return items.length?json({ok:true}):bad('Note not found.',404);
    }
    if (action === 'post-save' && post) {
      if(!ident(id)||typeof params.save!=='boolean')return bad('Invalid saved post.');
      const found=await sql('SELECT id FROM cc_posts WHERE id=$1',[id]);
      if(!found.length)return bad('Post not found.',404);
      if(params.save) await sql('INSERT INTO cc_saved_posts(user_id,post_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[uid,id]);
      else await sql('DELETE FROM cc_saved_posts WHERE user_id=$1 AND post_id=$2',[uid,id]);
      return json({ok:true});
    }
    if (action === 'focus-log' && post) {
      const minutes=Number(params.minutes);
      if(![15,25,45].includes(minutes))return bad('Invalid focus session.');
      const recent=await sql("SELECT count(*)::integer AS total FROM cc_focus_sessions WHERE owner_id=$1 AND created_at>now()-interval '10 minutes'",[uid]);
      if((recent[0]?.total||0)>=4)return bad('Focus history has been updated recently. Try again later.',429);
      await sql('INSERT INTO cc_focus_sessions(id,owner_id,minutes) VALUES($1,$2,$3)',[randomUUID(),uid,minutes]);
      return json({ok:true});
    }
    if (action === 'notify-read' && post) {
      await sql('UPDATE cc_notifications SET seen=true WHERE id=$1 AND user_id=$2',[id,uid]);return json({ok:true});
    }
    if (action === 'delete' && post) {
      const kind=text(params.kind,20);
      const types={post:['cc_posts','author_id'],task:['cc_assignments','author_id'],resource:['cc_resources','author_id'],deck:['cc_decks','owner_id'],event:['cc_events','owner_id'],announcement:['cc_announcements','author_id']};
      if(!ident(id)||!types[kind])return bad('Invalid item');
      const [table,owner]=types[kind];
      if(kind==='announcement'&&!isStaff(person))return bad('Admins only',403);
      const allowedToModerate=['post','task','resource','announcement'].includes(kind)&&isStaff(person);
      const record=(await sql(`SELECT ${owner}, ${kind==='resource'?'blob_key,':''}id FROM ${table} WHERE id=$1`,[id]))[0];
      if(!record) return bad('Not found',404);
      if(record[owner]!==uid&&!allowedToModerate)return bad('Only the author can delete this',403);
      await sql(`DELETE FROM ${table} WHERE id=$1`,[id]);
      if(kind==='resource'&&record.blob_key) await getStore('cloud-club-files').delete(record.blob_key);
      return json({ok:true});
    }
    return bad('Unknown action',404);
  } catch(error) { console.error('Cloud Club API error',error); return bad('The server had an issue. Try again.',500); }
}
export const config = { path: '/api/club' };
