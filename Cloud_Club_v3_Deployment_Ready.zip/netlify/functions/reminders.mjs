import { getDatabase } from '@netlify/database';
import { randomUUID } from 'node:crypto';
export default async function reminders() {
  const db=getDatabase();
  const client=await db.pool.connect();
  try {
    await client.query('BEGIN');
    const { rows }=await client.query(`UPDATE cc_events SET reminder_sent=true
      WHERE reminder_sent=false AND starts_at BETWEEN now() AND now()+interval '30 minutes'
      RETURNING owner_id,title`);
    for(const row of rows) await client.query('INSERT INTO cc_notifications(id,user_id,title,body) VALUES($1,$2,$3,$4)',[randomUUID(),row.owner_id,'Upcoming reminder',row.title]);
    await client.query('COMMIT');
  }catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
  return new Response('ok');
}
export const config={ schedule:'*/15 * * * *' };
