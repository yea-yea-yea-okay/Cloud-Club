# Cloud Club v3 — live acceptance checklist

**Run these on a Netlify Deploy Preview before sharing the site.** Use two or more invited test accounts, one configured owner and one regular member. A local Vite preview cannot verify hosted Identity/Database flows.

## Authentication
- [ ] Enable Identity and Google provider, confirm **Continue with Google** appears on deployed login page.
- [ ] Sign in using Google on a test account, verify successful redirect and dashboard load.
- [ ] Test email/password sign-up, confirmation email, login and logout.
- [ ] Request a forgotten-password email and complete reset with a new password.
- [ ] Cancel provider OAuth and verify the site returns to an appropriate login state.
- [ ] Sign out, refresh page, and verify protected content cannot be accessed.

## Community and classes
- [ ] Member A publishes a post, member B sees it after refresh and can vote on a poll.
- [ ] Member A bookmarks and unbookmarks a post, and sees it in My notebook.
- [ ] A member creates an assignment and marks it complete; another member cannot change its status.
- [ ] A creates a private class and shares the invite code with B; B joins.
- [ ] Uninvited C cannot read the class conversation by editing API requests.
- [ ] Member A uploads a supported small file. Member B can open it; guest cannot.
- [ ] Members can chat, remove their own messages and report unwanted messages.

## DMs, privacy, moderation
- [ ] DMs initially off on both accounts; A cannot message B until both opt in.
- [ ] Blocking stops either member from messaging; unblocking restores the option.
- [ ] A reports a received private message; moderator sees **only the reported excerpt**, not the whole conversation.
- [ ] Member cannot access owner moderation endpoint or suspend/promote other members.
- [ ] Owner promotes a member to admin and refreshes their session; role changes become effective.
- [ ] Owner suspends an account, sees it marked suspended and can **Restore** it.
- [ ] Owner publishes an announcement; member receives an in-app alert.
- [ ] Repeat chat/post actions quickly and verify anti-spam feedback.

## Personal tools and design
- [ ] Create, edit and delete a private note; a second member cannot read it through API requests.
- [ ] Test community saved posts, flashcard create/review, and personal calendar entries.
- [ ] Start/pause/reset a focus timer. Let a short preset finish and verify private focus history saves.
- [ ] Use global search with click + Ctrl/Cmd+K and Escape; verify results navigate to intended sections.
- [ ] Change all five themes, refresh, and confirm theme persists.
- [ ] Check mobile layout at ~375px, tap hamburger, navigate every page, complete a form.
- [ ] Check reduced-motion setting and keyboard focus visibility.
- [ ] Open Privacy and Community rules links.

## Deployment / migration
- [ ] `npm install && npm test && npm run build` all succeed in CI/Netlify.
- [ ] Netlify Database migrations have applied successfully.
- [ ] Scheduled reminders show up for due calendar entries.
- [ ] Old AppDeploy site remains untouched and no user data was silently copied.
- [ ] Review consent/privacy requirements before student enrollment.
