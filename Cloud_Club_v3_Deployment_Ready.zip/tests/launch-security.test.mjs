import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const backend = readFileSync('netlify/functions/api.mjs','utf8');
const packageJson = JSON.parse(readFileSync('package.json','utf8'));
const workflow = readFileSync('.github/workflows/verify.yml','utf8');
test('owner verified email is checked and stale owner is revoked',()=>{
  assert.match(backend,/myEmail === ownerEmail/);
  assert.match(backend,/SET role='member' WHERE role='owner'/);
  assert.doesNotMatch(backend,/\[ownerEmail && myEmail === ownerEmail \? myId : ''\]/);
});
test('student default profile does not copy full_name from OAuth',()=>{
  assert.doesNotMatch(backend,/identityUser\.userMetadata\?\.full_name/);
  assert.match(backend,/'Student ' \+ myId\.slice/);
});
test('GitHub checks exercise real build and backend syntax',()=>{
  assert.match(workflow,/npm run build/);
  assert.match(workflow,/npm test/);
  assert.match(workflow,/node --check netlify\/functions\/api\.mjs/);
  assert.match(packageJson.dependencies['@netlify/identity'],/^\^2\./);
});
