import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync('src/App.jsx', 'utf8');
const backend = readFileSync('netlify/functions/api.mjs', 'utf8');
const theme = readFileSync('src/style.css', 'utf8');
const migration = readFileSync('netlify/database/migrations/20261014064000_cloud_club_v3_notes_saves_focus.sql', 'utf8');

test('OAuth uses provider discovery and handles callbacks', () => {
  assert.match(source, /getSettings\(\)/);
  assert.match(source, /oauth\('google'\)/);
  assert.match(source, /authSettings\?\.providers\?\.google/);
  assert.match(source, /handleAuthCallback\(\)/);
  assert.match(source, /requestPasswordRecovery\(email\)/);
  assert.match(source, /updateUser\(\{password:newPassword\}\)/);
});

test('new navigation screens are implemented', () => {
  for (const [tab, title] of [['notes','Private notebook'], ['focus','Focus space'], ['help','Help & safety']]) {
    assert.ok(source.includes(`['${tab}'`) && source.includes(`tab==='${tab}'`), `missing ${tab}`);
    assert.ok(source.includes(title));
  }
  assert.match(source, /setSearchOpen\(true\)/);
  assert.match(source, /searchResults\.map/);
});

test('all new frontend mutations have backend action handlers', () => {
  for (const a of ['note-create','note-update','note-delete','post-save','focus-log']) {
    assert.ok(source.includes(`'${a}'`), `missing frontend action ${a}`);
    assert.ok(backend.includes(`action === '${a}'`), `missing backend handler ${a}`);
  }
});

test('private content and actions are scoped to the current member', () => {
  assert.match(backend, /cc_personal_notes WHERE owner_id=\$1/);
  assert.match(backend, /cc_personal_notes SET title=\$1,body=\$2,updated_at=now\(\) WHERE id=\$3 AND owner_id=\$4/);
  assert.match(backend, /cc_focus_sessions WHERE owner_id=\$1/);
  assert.match(backend, /cc_saved_posts WHERE user_id=\$1/);
  assert.match(backend, /both can be blocked|Both members must opt in/i);
  assert.match(backend, /await classMembership\(space\)/);
});

test('owner access does not default to first anonymous visitor', () => {
  assert.match(backend, /CLOUD_CLUB_OWNER_EMAIL/);
  assert.match(backend, /myEmail === ownerEmail/);
  assert.match(backend, /if\(person\.role!=='owner'\)/);
});

test('schema and responsive styling are available', () => {
  for (const table of ['cc_personal_notes','cc_saved_posts','cc_focus_sessions']) assert.ok(migration.includes(table));
  assert.match(theme, /\.oauth-button/);
  assert.match(theme, /\.focus-ring/);
  assert.match(theme, /\.mobile-menu-button/);
  assert.match(theme, /prefers-reduced-motion/);
});

test('public content has moderation and spam guardrails', () => {
  assert.match(backend, /if \(action === 'report' && post\)/);
  assert.match(backend, /if \(action === 'report-resolve' && post\)/);
  assert.match(backend, /'30 seconds'/);
  assert.match(backend, /'10 minutes'/);
});
