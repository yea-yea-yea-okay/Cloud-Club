# Cloud Club v3 — student community for Netlify

Cloud Club is a responsive student workspace built with React, Vite, Netlify Identity, Netlify Functions, Netlify Database (Postgres), and Netlify Blobs. The original AppDeploy website remains separate and is **not modified**.

## What is included

**Account & discovery:** Email sign-up, login, real Google/GitHub sign-in buttons controlled by Netlify Identity's enabled-provider settings, email password recovery, global search (⌘/Ctrl + K), custom profiles, five themes, mobile navigation and a Help & Safety page.

**School & community:** Student dashboard, shared assignments, private invitation-code classes and discussions, shared community channels, posts, polls, voting, resource links and file uploads, announcements, member moderation and reports, in-app notifications and calendar reminders.

**Personal features:** Flashcards with review progress, personal calendar, private notebook (create/edit/delete), saved community posts and a 15/25/45-minute focus timer with private completed-session history.

**Safety & privacy:** DMs off by default, reciprocal DM opt-in, blocks, report-only excerpts from private conversations, group-membership verification on the backend, author/owner checks for actions, rate limiting on posts/messages, and a verified email allowlist for owner access.


## Launch-state checklist (current)

- **Verified locally:** `npm test` and server-side JavaScript syntax checks; React JSX syntax parsed successfully. The GitHub workflow additionally attempts a real Vite build on every push and PR.
- **Not yet done:** private GitHub repository creation, source upload, connecting Netlify to the repository, enabling Netlify Identity + Google OAuth, provisioning and migrating the Netlify Database, and live authentication/permission testing. Never claim a live release until Netlify reports a successful deploy.
- **Account roles:** `CLOUD_CLUB_OWNER_EMAIL` must be set privately in Netlify with an email verified through Netlify Identity. The backend starts new users with pseudonymous profiles and rechecks the configured owner when an account makes API requests.
- **Safety:** keep registration Invite-only while student privacy rules, retention and data deletion, moderation handling, and age/guardian requirements are reviewed. Private chats are not secretly accessible to administrators; only reported excerpts can enter their report queue.
- **GitHub connection:** the ChatGPT GitHub integration only has access to repositories the GitHub app has been authorized for. Creating a Netlify site does **not** create a repository or deploy files; connect the repository using your Netlify project dashboard.

## Setup: publish v3 to your existing Netlify project

The Netlify account already has a project named **cloud-club-students**:

https://app.netlify.com/projects/cloud-club-students

**The project is not live yet.** Creating a project does not deploy the source. The Netlify tools currently connected in chat can create and manage the project, but cannot upload code/deploy a ZIP directly. Use a Git-connected deploy so future updates happen automatically.

1. Extract `Cloud_Club_v3_Netlify.zip` on your computer. Its contents, **not the containing folder**, should be at the root of your new GitHub repository. Keep `.env` and any API keys out of the repository. The included `.gitignore` excludes `.netlify` and environment files.
2. In the existing **cloud-club-students** Netlify project, select **Project configuration → Build & deploy → Continuous deployment → Connect repository** (labels may vary). Select the GitHub repository. Build command: `npm run build`. Publish directory: `dist`. Base directory: repository root. Netlify Functions directory: `netlify/functions` (also in `netlify.toml`).
3. In the Netlify project's **Identity** tab, click **Enable Identity**. Under **Registration → External providers**, enable **Google** and optionally **GitHub**. The app reads the live provider settings via `getSettings()`, so only enabled provider buttons appear. The OAuth redirect and invite confirmation use `handleAuthCallback()`.
4. For a private student beta, choose **Invite only** under Identity registration settings. Invite students individually under **Identity → Users**. This also applies to new users who choose Google sign-in. Later you can change the setting after privacy, moderation, age requirements, and consent have been reviewed.
5. In Netlify project **Environment variables**, create `CLOUD_CLUB_OWNER_EMAIL` with the exact email of the owner's verified Netlify Identity account. Make it available to **Functions** scope in Production. **Do not write the email into frontend code or public files**. Redeploy after setting this. Unlike a first-visitor trick, only this verified identity gets the owner role. Sign out and back in after changing a role to ensure the new role is active.
6. Ensure Netlify Database is available. The repository has `@netlify/database` installed and migration files under `netlify/database/migrations/`. Netlify applies migrations on deployments when the database is provisioned on a supported account plan; it may use billable credits. Do not run `drizzle-kit push` or manually reset a production database.
7. Open the deployed URL. Verify Google sign-in, email/password, owner controls, private class membership, file sharing, polls, notes, reminders and other flows using **at least two test accounts**. Follow `tests/MANUAL_QA.md` before inviting real students.
8. Review the draft Privacy page, Terms/community rules, data deletion workflows, and age eligibility with a responsible adult before a public launch. The app is a technical beta, not a legal/compliance/security audit.

### Google sign-in details

`oauthLogin('google')` is a **real redirect**, not a fake button. It appears only when Google is enabled for this project's Netlify Identity service. If it doesn't appear, check the project under **Identity → Registration → External providers → Add provider → Google**. Netlify may show its own service name in the Google consent window when using Netlify's default OAuth credentials; custom branding requires the provider's own OAuth app credentials configured privately in the Netlify settings UI, never hardcoded.

## How to update Cloud Club later

Use **GitHub continuous deployment**. After Netlify is connected to your GitHub repository, update any source file (`src/App.jsx` for components; `src/style.css` for visual styles; `netlify/functions/api.mjs` for server actions; `netlify/database/migrations/` for new tables). Commit and push to your site's **production branch** (typically `main`). Netlify detects the push, runs `npm run build`, applies compatible database migrations, and atomically publishes the new version when the deploy succeeds.

For bigger changes: use a **feature branch + pull request** to get a Netlify Deploy Preview; test before merging. **Previews may contain copied production data if Netlify Database preview branching is enabled, so do not share preview links publicly.** Avoid replacing production files manually on a Git-connected Netlify site—the next Git push may overwrite the manual deploy.

To check results: open Netlify **Deploys** for the `cloud-club-students` project, select the latest deploy, and inspect the build log, function logs, and deployed URL. If deployment fails, the existing published site stays live.

## Local work and testing

Requirements: Node.js 20+.

```bash
npm install
npm test
npm run dev
npm run build
```

`npm test` runs static source-contract checks for routes, privacy, social login and navigation. Identity **must be tested on a Netlify Deploy Preview or production URL**, not plain `vite dev`; the Netlify CLI can run local function and database emulation. The full functional check is in `tests/MANUAL_QA.md`.

**Validation status:** Local Node syntax check for Netlify functions, TypeScript JSX parsing, seven source-contract tests, and click-action audit for React `<button>` nodes passed. Installing npm packages in this environment timed out, so **the production Vite bundle and end-to-end Netlify services were NOT verified**. Those remain deployment acceptance steps.

## Data migration: important

The original Cloud Club was hosted on AppDeploy with different accounts, databases and file storage. Publishing the Netlify edition does **not** transfer the existing users, messages, assignments, files or owner role. Do not shut down or delete the original project. Migration requires an explicit secure data-export/mapping workflow before a cut-over, particularly for accounts and private messages. Existing Netlify edition v2 data is preserved by the additive v3 database migration.

## Project structure

- `src/App.jsx` — student-facing React app
- `src/style.css` — responsive styling, themes, animation, typography
- `netlify/functions/api.mjs` — authenticated API, role checks, CRUD
- `netlify/functions/reminders.mjs` — scheduled in-app reminders (runs every 15 minutes)
- `netlify/database/migrations` — Postgres schema and v3 additive migration
- `public` — privacy/community rules and favicon
- `tests` — source contract tests and human acceptance checklist
- `netlify.toml` — Netlify build & function configuration

## Design references (inspiration, not copied)

Original layout direction draws from contemporary student interfaces that use card-based organization, a clean vertical navigation rail and a warm/pastel dashboard palette. Inspirational references include:
- [FocusMate student dashboard — Dribbble](https://dribbble.com/shots/25879967-Dashboard-Design-for-Students)
- [EduMe learning dashboard — Dribbble](https://dribbble.com/shots/26979884-EduMe-Learning-Dashboard-UI)
- [Group study dashboard — Dribbble](https://dribbble.com/tags/group-study)

No reference UI, images, or copyrighted visual designs were copied into the source.
